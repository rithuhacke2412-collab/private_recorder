import { DEFAULTS, FORMATS, QUALITY, hostFromUrl, isAllowedHost, isAllowedUrl, safeFileName, sanitizeSettings } from './shared.js';

const POPUP_URL = chrome.runtime.getURL('popup.html');
const OFFSCREEN_URL = chrome.runtime.getURL('offscreen.html');
const BLOB_PREFIX = `blob:${chrome.runtime.getURL('').slice(0, -1)}/`;
const ALARM_NAME = 'private-recorder:max-duration';

const emptyState = () => ({ status: 'idle' });
const isObject = x => x && typeof x === 'object' && !Array.isArray(x);
const sameExt = (a, b) => typeof a === 'string' && a === b;
const safeToken = () => (crypto.randomUUID ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join(''));

const fromPopup = sender => sender.id === chrome.runtime.id && sender.url === POPUP_URL;
const fromOffscreen = sender => sender.id === chrome.runtime.id && sender.url === OFFSCREEN_URL;
const fromTab = sender => sender.id === chrome.runtime.id && sender.tab && Number.isInteger(sender.tab.id) && sender.tab.id >= 0;

async function readSettings() {
  const raw = await chrome.storage.local.get(DEFAULTS);
  const safe = sanitizeSettings(raw);
  await chrome.storage.local.set(safe);
  return safe;
}

async function getState() {
  const { state } = await chrome.storage.session.get('state');
  return state && typeof state === 'object' ? state : emptyState();
}

async function setState(state) {
  await chrome.storage.session.set({ state });
  const text = ['recording'].includes(state.status) ? 'REC' : ['starting', 'working', 'selecting'].includes(state.status) ? '…' : '';
  await chrome.action.setBadgeText({ text });
  if (text) await chrome.action.setBadgeBackgroundColor({ color: '#c8322b' });
}

async function clearMaxAlarm() {
  try { await chrome.alarms.clear(ALARM_NAME); } catch {}
}

async function armMaxAlarm(minutes, token) {
  await clearMaxAlarm();
  chrome.alarms.create(ALARM_NAME, { delayInMinutes: Math.max(1, Number(minutes) || DEFAULTS.maxMinutes) });
  await chrome.storage.session.set({ maxAlarmToken: token });
}

let creatingOffscreen = null;
async function ensureOffscreen() {
  if (creatingOffscreen) return creatingOffscreen;
  const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [OFFSCREEN_URL] });
  if (contexts.length) return;
  creatingOffscreen = chrome.offscreen.createDocument({
    url: 'offscreen.html', reasons: ['USER_MEDIA', 'BLOBS'],
    justification: 'Record the audio/video of the tab the user explicitly selected and create a local file.'
  }).finally(() => { creatingOffscreen = null; });
  return creatingOffscreen;
}

async function closeOffscreen() {
  try {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [OFFSCREEN_URL] });
    if (contexts.length) await chrome.offscreen.closeDocument();
  } catch {}
}

const toOffscreen = msg => chrome.runtime.sendMessage({ target: 'offscreen', ...msg });
async function detach(tabId) {
  if (!Number.isInteger(tabId)) return;
  try { await chrome.tabs.sendMessage(tabId, { type: 'detach' }); } catch {}
}

async function abortState(error, tabId) {
  await clearMaxAlarm();
  await setState({ status: 'error', error: String(error || 'Recording failed.').slice(0, 240) });
  if (Number.isInteger(tabId)) await detach(tabId);
  await closeOffscreen();
}

function validateStartMessage(msg) {
  return isObject(msg) &&
    Object.prototype.hasOwnProperty.call(FORMATS, msg.format) &&
    Number.isInteger(msg.tabId) && msg.tabId >= 0 &&
    typeof msg.autoStop === 'boolean' &&
    typeof msg.title === 'string' && msg.title.length <= 500;
}

async function getApprovedTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const url = String(tab?.url || '');
  const host = hostFromUrl(url);
  const settings = await readSettings();
  if (!host || !isAllowedUrl(url, settings)) throw new Error('This site is not enabled. Open Settings → Trusted sites to allow it.');
  return { tab, host, settings };
}

async function beginCapture({ token, tabId, host, format, autoStop, title, maxMinutes }) {
  const settings = await readSettings();
  const tab = await chrome.tabs.get(tabId);
  if (!tab || !isAllowedUrl(tab.url || '', settings)) throw new Error('The approved site changed or is no longer allowed.');
  const currentHost = hostFromUrl(tab.url || '');
  if (currentHost !== host) throw new Error('Recording is bound to one approved site and cannot follow a navigation.');

  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  await ensureOffscreen();
  const r = await toOffscreen({ type: 'start', token, streamId, format, quality: 'high' });
  if (!r?.ok) throw new Error(r?.error || 'Could not start the recorder.');

  await setState({ status: 'recording', token, tabId, host, format, quality: 'high', area: 'full', autoStop, title: title.slice(0, 500), startedAt: Date.now(), maxMinutes });
  await armMaxAlarm(maxMinutes, token);
  return true;
}

async function prepareStart(msg) {
  if (!validateStartMessage(msg)) return { ok: false, error: 'Bad request.' };
  const s = await getState();
  if (['starting', 'recording', 'working'].includes(s.status)) return { ok: false, error: 'A recording is already in progress.' };
  const { tab, host, settings } = await getApprovedTab(msg.tabId);
  const token = safeToken();
  await setState({ status: 'starting', token, tabId: msg.tabId, host, areaMode: 'full', format: msg.format, quality: 'high', autoStop: msg.autoStop, title: String(tab.title || msg.title || 'recording'), maxMinutes: settings.maxMinutes });
  try {
    await beginCapture({ token, tabId: msg.tabId, host, format: msg.format, autoStop: msg.autoStop, title: String(tab.title || msg.title || 'recording'), maxMinutes: settings.maxMinutes });
    await chrome.scripting.executeScript({ target: { tabId: msg.tabId }, files: ['content.js'] });
    await chrome.tabs.sendMessage(msg.tabId, { type: 'watch', token, autoStop: msg.autoStop, host }).catch(() => {});
    return { ok: true };
  } catch (e) {
    await abortState(e.message, msg.tabId);
    return { ok: false, error: e.message };
  }
}

async function stopRecording(reason = 'manual') {
  const s = await getState();
  if (!['recording', 'starting', 'selecting'].includes(s.status)) return;
  await clearMaxAlarm();
  if (s.status === 'selecting') {
    await chrome.tabs.sendMessage(s.tabId, { type: 'cancel-select', token: s.token }).catch(() => {});
    await setState({ status: reason === 'max-duration' ? 'error' : 'idle', ...(reason === 'max-duration' ? { error: 'Maximum recording duration reached.' } : {}) });
    await detach(s.tabId);
    return;
  }
  if (s.status === 'starting') {
    await setState({ ...s, status: 'working' });
    try { await toOffscreen({ type: 'stop', token: s.token }); } catch {}
    return;
  }
  await setState({ ...s, status: 'working' });
  try { await toOffscreen({ type: 'stop', token: s.token }); }
  catch { await abortState('The recorder stopped unexpectedly.', s.tabId); }
}

async function handle(msg, sender) {
  if (!isObject(msg)) return { ok: false, error: 'Bad request.' };
  const s = await getState();

  if (msg.type === 'prepare-start') {
    if (!fromPopup(sender)) return { ok: false, error: 'Not allowed.' };
    return prepareStart(msg);
  }
  if (msg.type === 'stop') {
    if (!fromPopup(sender)) return { ok: false, error: 'Not allowed.' };
    await stopRecording('manual');
    return { ok: true };
  }
  if (msg.type === 'media-ended') {
    if (fromTab(sender) && s.status === 'recording' && s.autoStop && sender.tab.id === s.tabId && msg.token === s.token) {
      setTimeout(() => stopRecording('ended').catch(() => {}), 350);
    }
    return { ok: true };
  }
  if (msg.type === 'ad-state') {
    if (fromTab(sender) && s.status === 'recording' && sender.tab.id === s.tabId && msg.token === s.token && typeof msg.ad === 'boolean') {
      try { await toOffscreen({ type: msg.ad ? 'pause' : 'resume', token: s.token }); } catch {}
    }
    return { ok: true };
  }
  if (msg.type === 'offscreen-finished') {
    if (!fromOffscreen(sender) || !['recording', 'working'].includes(s.status) || msg.token !== s.token) return { ok: false, error: 'Not allowed.' };
    if (typeof msg.url !== 'string' || !msg.url.startsWith(BLOB_PREFIX) || !sameExt(msg.ext, s.format) || !Object.prototype.hasOwnProperty.call(FORMATS, msg.ext)) {
      await abortState('Blocked an unexpected file.', s.tabId);
      return { ok: false, error: 'Unexpected file.' };
    }
    const expectedKinds = { mp4: 'video/mp4', webm: 'video/webm', m4a: 'audio/mp4', mp3: 'audio/mpeg', wav: 'audio/wav' };
    if (msg.mime !== expectedKinds[msg.ext]) {
      await abortState('Blocked a file with an unexpected MIME type.', s.tabId);
      return { ok: false, error: 'Unexpected MIME type.' };
    }
    try {
      const filename = safeFileName(s.title, s.format, new Date());
      const id = await chrome.downloads.download({ url: msg.url, filename, saveAs: false, conflictAction: 'uniquify' });
      await chrome.storage.session.set({ pendingBlobUrl: msg.url, pendingDownloadId: id });
      await setState({ status: 'done', file: filename, downloadId: id, tabId: s.tabId, note: reasonNote(s.format) });
    } catch (e) {
      await abortState('Could not save the file.', s.tabId);
      return { ok: false, error: 'Could not save the file.' };
    }
    await detach(s.tabId);
    return { ok: true };
  }
  if (msg.type === 'offscreen-error') {
    if (!fromOffscreen(sender) || msg.token !== s.token) return { ok: false, error: 'Not allowed.' };
    await abortState(String(msg.error || 'Recording failed.'), s.tabId);
    return { ok: true };
  }
  return { ok: false, error: 'Unknown message.' };
}

function reasonNote(format) {
  return format === 'wav' ? 'WAV is uncompressed and can be much larger than compressed audio.' : 'Saved locally. No upload or external service is used.';
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'background') return;
  handle(msg, sender).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e.message || e) }));
  return true;
});

chrome.downloads.onChanged.addListener(async delta => {
  if (!delta.id || !delta.state || !['complete', 'interrupted'].includes(delta.state.current)) return;
  const s = await getState();
  if (s.status !== 'done' || s.downloadId !== delta.id) return;
  const { pendingBlobUrl } = await chrome.storage.session.get('pendingBlobUrl');
  if (pendingBlobUrl) await toOffscreen({ type: 'release', token: s.token, url: pendingBlobUrl }).catch(() => {});
  await chrome.storage.session.remove(['pendingBlobUrl', 'pendingDownloadId', 'maxAlarmToken']);
  await closeOffscreen();
  if (s.tabId != null) await detach(s.tabId);
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== ALARM_NAME) return;
  const { maxAlarmToken } = await chrome.storage.session.get('maxAlarmToken');
  const s = await getState();
  if (maxAlarmToken && s.token === maxAlarmToken) await stopRecording('max-duration');
});

chrome.tabs.onRemoved.addListener(async tabId => {
  const s = await getState();
  if (['recording', 'starting', 'selecting'].includes(s.status) && s.tabId === tabId) await stopRecording('tab-closed');
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const s = await getState();
  if (!['recording', 'starting', 'selecting'].includes(s.status) || s.tabId !== tabId) return;
  const settings = await readSettings();
  const host = hostFromUrl(changeInfo.url);
  if (!host || host !== s.host || !isAllowedUrl(changeInfo.url, settings)) await stopRecording('navigation');
});

chrome.runtime.onStartup.addListener(async () => {
  await clearMaxAlarm();
  await setState(emptyState());
});

chrome.runtime.onInstalled.addListener(async () => {
  await readSettings();
  await clearMaxAlarm();
  await setState(emptyState());
});
