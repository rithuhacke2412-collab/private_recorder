(() => {
  if (window.__privateRecorder) return;
  window.__privateRecorder = true;

  let lastAdTime = 0;
  let lastAd = false;
  let watchToken = '';
  let timer = 0;
  let armed = false;

  const send = message => {
    try { chrome.runtime.sendMessage({ target: 'background', ...message }).catch(() => {}); } catch {}
  };

  const isYouTubeHost = () => /(^|\.)youtube\.com$/.test(location.hostname) || location.hostname === 'music.youtube.com';
  const adShowing = () => isYouTubeHost() && !!document.querySelector('.ad-showing, .ad-interrupting, .ytp-ad-player-overlay');

  const onEnded = event => {
    if (!armed || !watchToken || !(event.target instanceof HTMLMediaElement)) return;
    if (adShowing() || Date.now() - lastAdTime < 1500) return;
    send({ type: 'media-ended', token: watchToken });
  };
  const startWatch = (token, autoStop) => {
    watchToken = token; armed = !!autoStop; lastAdTime = 0; lastAd = false;
    document.addEventListener('ended', onEnded, true);
    clearInterval(timer);
    timer = window.setInterval(() => {
      const ad = adShowing();
      if (ad) lastAdTime = Date.now();
      if (ad !== lastAd && watchToken) { lastAd = ad; send({ type: 'ad-state', token: watchToken, ad }); }
    }, 300);
  };

  const onMsg = msg => {
    if (!msg || !msg.type) return;
    if (msg.type === 'watch' && typeof msg.token === 'string') startWatch(msg.token, msg.autoStop);
    else if (msg.type === 'cancel-select' && msg.token) removeSelector();
    else if (msg.type === 'detach') {
      clearInterval(timer); document.removeEventListener('ended', onEnded, true); chrome.runtime.onMessage.removeListener(onMsg); window.__privateRecorder = false;
    }
  };

  chrome.runtime.onMessage.addListener(onMsg);
})();
