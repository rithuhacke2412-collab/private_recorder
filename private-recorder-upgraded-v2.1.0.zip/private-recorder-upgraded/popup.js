import { FORMATS, DEFAULTS, clock, isAllowedUrl, hostFromUrl, sanitizeSettings } from './shared.js';

const $ = id => document.getElementById(id);
const startBtn=$('startBtn'), stopBtn=$('stopBtn'), msg=$('msg'), hint=$('hint'), timer=$('timer');
const settingsBtn=$('settingsBtn'), siteName=$('siteName'), siteHint=$('siteHint'), siteState=$('siteState'), formatHint=$('formatHint');
let state={status:'idle'}, tick=0, settings=sanitizeSettings(DEFAULTS), activeTab=null, mediaSupport={};
const selected=name=>document.querySelector(`input[name="${name}"]:checked`)?.value;
const setMsg=(text,error=false)=>{msg.textContent=text;msg.className=error?'err':''};
const input=(name,value)=>document.querySelector(`input[name="${name}"][value="${value}"]`);

function updateCapability(){
  for(const [id,info] of Object.entries(FORMATS)) mediaSupport[id]=info.mimes.some(m=>MediaRecorder.isTypeSupported(m));
  for(const id of Object.keys(FORMATS)){const el=input('fmt',id);if(!el)continue;el.disabled=!mediaSupport[id];el.closest('label').title=mediaSupport[id]?'':`${FORMATS[id].label} is not supported by this Chromium build.`}
  if(!mediaSupport[selected('fmt')]){const fallback=Object.keys(FORMATS).find(id=>mediaSupport[id]);if(fallback)input('fmt',fallback).checked=true}
}
function renderSite(){
  const url=activeTab?.url||'',host=hostFromUrl(url),allowed=!!host&&isAllowedUrl(url,settings);
  siteName.textContent=host||'Unsupported tab';siteHint.textContent=allowed?'Trusted site enabled for recording.':'Only enabled HTTPS sites can be recorded.';
  siteState.textContent=allowed?'Allowed':'Blocked';siteState.className='pill '+(allowed?'ok':'bad');
  startBtn.disabled=!allowed||['starting','recording','working'].includes(state.status);
}
function render(s){
  state=s||{status:'idle'};const rec=state.status==='recording',busy=['starting','working'].includes(state.status);
  document.body.classList.toggle('rec',rec);startBtn.hidden=rec;stopBtn.hidden=!rec;startBtn.disabled=busy||!isAllowedUrl(activeTab?.url||'',settings);stopBtn.disabled=!rec;
  document.querySelectorAll('input').forEach(el=>el.disabled=rec||busy||(el.name==='fmt'&&mediaSupport[el.value]===false));
  if(rec){const el=input('fmt',state.format);if(el)el.checked=true;$('autoStop').checked=!!state.autoStop}
  clearInterval(tick);timer.hidden=!rec;
  if(rec){const started=state.startedAt;const update=()=>timer.textContent=clock((Date.now()-started)/1000);update();tick=setInterval(update,500);setMsg('Recording');hint.textContent=`Capturing the entire tab · ${FORMATS[state.format]?.label||state.format}`;}
  else if(state.status==='working'){setMsg('Finalizing…');hint.textContent='Preparing your local recording.'}
  else if(state.status==='done'){setMsg('Saved');hint.textContent=state.note||'The file is in your Downloads folder.'}
  else if(state.status==='error'){setMsg(state.error||'Something went wrong.',true);hint.textContent='Check the trusted site and format, then try again.'}
  else{setMsg('Ready');hint.textContent='The whole tab will be captured at the fixed quality.'}
}
async function load(){
  const raw=await chrome.storage.local.get(DEFAULTS);settings=sanitizeSettings(raw);await chrome.storage.local.set(settings);
  input('fmt',settings.fmt).checked=true;$('autoStop').checked=settings.autoStop;updateCapability();
  [activeTab]=await chrome.tabs.query({active:true,currentWindow:true});renderSite();
  const {state:s}=await chrome.storage.session.get('state');render(s);
}
async function savePrefs(){settings=sanitizeSettings({...settings,fmt:selected('fmt'),autoStop:$('autoStop').checked});await chrome.storage.local.set(settings);renderSite()}
async function start(){
  try{[activeTab]=await chrome.tabs.query({active:true,currentWindow:true});if(!activeTab?.id||!isAllowedUrl(activeTab.url||'',settings))throw new Error('This tab is not enabled. Open Settings → Trusted sites to allow it.');
    const format=selected('fmt');if(!mediaSupport[format])throw new Error(`${FORMATS[format].label} is not supported by this browser.`);
    await savePrefs();const r=await chrome.runtime.sendMessage({target:'background',type:'prepare-start',tabId:activeTab.id,format,autoStop:$('autoStop').checked,title:activeTab.title||''});
    if(!r?.ok)throw new Error(r?.error||'Could not start recording.');const {state:s}=await chrome.storage.session.get('state');render(s);
  }catch(e){setMsg(String(e.message||e),true)}
}
startBtn.addEventListener('click',start);stopBtn.addEventListener('click',()=>chrome.runtime.sendMessage({target:'background',type:'stop'}).catch(()=>{}));settingsBtn.addEventListener('click',()=>chrome.runtime.openOptionsPage());
document.querySelectorAll('input[name="fmt"]').forEach(el=>el.addEventListener('change',savePrefs));$('autoStop').addEventListener('change',savePrefs);
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&Object.keys(changes).length){load().catch(()=>{})}if(area==='session'&&changes.state)render(changes.state.newValue)});
window.addEventListener('beforeunload',()=>clearInterval(tick));load().catch(e=>setMsg(e.message||'Could not load settings.',true));
