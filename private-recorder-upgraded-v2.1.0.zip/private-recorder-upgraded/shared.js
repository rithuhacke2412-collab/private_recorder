// Private Recorder shared policy/helpers. No browser APIs are used here.

export const PRESETS = [
  { id: 'youtube', name: 'YouTube', hosts: ['youtube.com', 'www.youtube.com', 'm.youtube.com'] },
  { id: 'ytmusic', name: 'YouTube Music', hosts: ['music.youtube.com'] },
  { id: 'prime', name: 'Prime Video', hosts: ['primevideo.com', 'www.primevideo.com'] },
  { id: 'netflix', name: 'Netflix', hosts: ['netflix.com', 'www.netflix.com'] },
  { id: 'spotify', name: 'Spotify', hosts: ['open.spotify.com'] },
  { id: 'hotstar', name: 'JioHotstar / Hotstar', hosts: ['hotstar.com', 'www.hotstar.com', 'jiohotstar.com', 'www.jiohotstar.com'] }
];

export const FORMATS = Object.freeze({
  mp4: { kind: 'video', ext: 'mp4', label: 'MP4', note: 'H.264 + AAC. Broad compatibility.', mimes: ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4'] },
  webm: { kind: 'video', ext: 'webm', label: 'WebM', note: 'VP9 + Opus. Excellent quality per MB.', mimes: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'] },
  m4a: { kind: 'audio', ext: 'm4a', label: 'M4A', note: 'AAC audio only. Small and widely supported.', mimes: ['audio/mp4;codecs=mp4a.40.2', 'audio/mp4'] },
  wav: { kind: 'audio', ext: 'wav', label: 'WAV', note: 'Uncompressed PCM. Very large files.', mimes: ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm'] },
  mp3: { kind: 'audio', ext: 'mp3', label: 'MP3', note: 'Compressed audio. Compact and widely supported.', mimes: ['audio/mpeg'] }
});


export const QUALITY = Object.freeze({
  standard: { label: 'Standard', maxW: 1920, maxH: 1080, fps: 30, vbps: 10e6, abps: 192e3, video: 'up to 1080p · 30 fps', audio: '192 kbps AAC/Opus' },
  high: { label: 'High', maxW: 2560, maxH: 1440, fps: 60, vbps: 24e6, abps: 256e3, video: 'up to 1440p · 60 fps', audio: '256 kbps AAC/Opus' },
  max: { label: 'Maximum', maxW: 3840, maxH: 2160, fps: 60, vbps: 45e6, abps: 320e3, video: 'up to 4K · 60 fps', audio: '320 kbps AAC/Opus' }
});

export const MAX_MINUTES = Object.freeze([30, 60, 120, 180, 240]);
export const DEFAULTS = Object.freeze({
  fmt: 'mp4', quality: 'high', autoStop: true,
  presets: Object.freeze(Object.fromEntries(PRESETS.map(p => [p.id, true]))),
  custom: Object.freeze([]), maxMinutes: 180
});

const PUBLIC_SUFFIXES = new Set([
  'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'com.au', 'net.au', 'org.au', 'co.in', 'net.in', 'org.in',
  'com.br', 'co.jp', 'co.nz', 'co.za', 'com.sg', 'com.cn', 'com.hk', 'com.tw', 'com.mx', 'com.tr',
  'com.sa', 'com.qa', 'com.eg', 'com.pk', 'co.kr', 'co.id', 'com.my', 'com.ph', 'com.ar', 'co.il'
]);
const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

export function hostFromUrl(url) {
  try {
    const u = new URL(String(url));
    if (u.protocol !== 'https:' || u.username || u.password) return null;
    if (u.port && u.port !== '443') return null;
    const h = u.hostname.toLowerCase().replace(/\.$/, '');
    return h || null;
  } catch { return null; }
}

export function normalizeEntry(input) {
  let s = String(input == null ? '' : input).trim().toLowerCase();
  if (!s) return { ok: false, error: 'Enter a site like example.com.' };
  const wildcard = s.startsWith('*.');
  if (wildcard) s = s.slice(2);
  if (/^https?:\/\//.test(s)) {
    try { s = new URL(s).hostname; } catch { return { ok: false, error: 'That is not a valid site address.' }; }
  } else {
    s = s.split(/[/?#]/)[0];
  }
  if (/[\s:@*]/.test(s)) return { ok: false, error: 'Use a hostname only: no login, port, or extra wildcards.' };
  try { s = new URL('https:' + '//' + s).hostname; } catch { return { ok: false, error: 'That is not a valid site address.' }; }
  s = s.replace(/\.$/, '');
  if (!/^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:[a-z]{2,24}|xn--[a-z0-9-]{2,59})$/.test(s)) {
    return { ok: false, error: 'Use a full site name like example.com.' };
  }
  const labels = s.split('.');
  if (labels.length === 2 && PUBLIC_SUFFIXES.has(s)) return { ok: false, error: 'That is a registry suffix, not a site.' };
  return { ok: true, value: (wildcard ? '*.' : '') + s };
}

export function sanitizeSettings(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const out = {
    fmt: own(FORMATS, r.fmt) ? r.fmt : DEFAULTS.fmt,
    quality: 'high',
    autoStop: typeof r.autoStop === 'boolean' ? r.autoStop : DEFAULTS.autoStop,
    presets: {}, custom: [],
    maxMinutes: MAX_MINUTES.includes(r.maxMinutes) ? r.maxMinutes : DEFAULTS.maxMinutes
  };
  const rp = r.presets && typeof r.presets === 'object' ? r.presets : {};
  for (const p of PRESETS) out.presets[p.id] = typeof rp[p.id] === 'boolean' ? rp[p.id] : true;
  if (Array.isArray(r.custom)) {
    for (const item of r.custom) {
      const n = normalizeEntry(item);
      if (n.ok && n.value === item && !out.custom.includes(n.value) && out.custom.length < 50) out.custom.push(n.value);
    }
  }
  return out;
}

export function allowedEntries(settings) {
  const safe = sanitizeSettings(settings);
  const list = [];
  for (const p of PRESETS) if (safe.presets[p.id]) list.push(...p.hosts);
  list.push(...safe.custom);
  return list;
}

export function isAllowedHost(host, settings) {
  const h = String(host || '').toLowerCase().replace(/\.$/, '');
  if (!h) return false;
  for (const e of allowedEntries(settings)) {
    if (e.startsWith('*.')) {
      const suffix = e.slice(1);
      if (h.endsWith(suffix) && h.length > suffix.length) return true;
    } else if (h === e) return true;
  }
  return false;
}

export function isAllowedUrl(url, settings) {
  const host = hostFromUrl(url);
  return !!host && isAllowedHost(host, settings);
}

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
export function cleanRect(r) {
  if (!r || typeof r !== 'object') return null;
  const { x, y, w, h } = r;
  if (![x, y, w, h].every(Number.isFinite)) return null;
  const cx = clamp(x, 0, 1), cy = clamp(y, 0, 1);
  const cw = clamp(w, 0, 1 - cx), ch = clamp(h, 0, 1 - cy);
  if (cw < 0.02 || ch < 0.02) return null;
  return { x: cx, y: cy, w: cw, h: ch };
}

export function cropPx(r, fw, fh) {
  if (!Number.isFinite(fw) || !Number.isFinite(fh) || fw < 2 || fh < 2) throw new Error('Invalid frame size.');
  const sx = clamp(Math.round(r.x * fw), 0, fw - 2);
  const sy = clamp(Math.round(r.y * fh), 0, fh - 2);
  const sw = clamp(Math.round(r.w * fw), 2, fw - sx);
  const sh = clamp(Math.round(r.h * fh), 2, fh - sy);
  return { sx, sy, sw, sh };
}

const even = n => Math.max(2, Math.round(n) - (Math.round(n) % 2));
export function fitEven(cw, ch, maxW, maxH, allowUp = false) {
  if (![cw, ch, maxW, maxH].every(Number.isFinite) || cw <= 0 || ch <= 0) throw new Error('Invalid dimensions.');
  let scale = Math.min(maxW / cw, maxH / ch);
  if (!allowUp) scale = Math.min(1, scale);
  return { w: even(cw * scale), h: even(ch * scale) };
}

const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
export function safeFileName(title, ext, now = new Date()) {
  if (!/^[a-z0-9]{1,5}$/i.test(String(ext || ''))) throw new Error('Invalid output extension.');
  let t = String(title || 'recording')
    .replace(/ - YouTube( Music)?$/i, '')
    .replace(/[\\/:*?"<>|\u0000-\u001f\u007f\u200b-\u200f\u202a-\u202e\u2066-\u2069]+/g, ' ')
    .replace(/\s+/g, ' ').trim();
  t = Array.from(t).slice(0, 80).join('').replace(/^[.\s]+|[.\s]+$/g, '');
  if (!t || RESERVED.test(t.split('.')[0])) t = t ? '_' + t : 'recording';
  const p = n => String(n).padStart(2, '0');
  const stamp = `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}-${p(now.getMinutes())}`;
  return `Private Recorder/${t} ${stamp}.${String(ext).toLowerCase()}`;
}

export const pad2 = n => String(n).padStart(2, '0');
export function clock(totalSeconds) {
  const t = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  return (h ? h + ':' + pad2(m) : pad2(m)) + ':' + pad2(s);
}

export function estimateSizeMB(format, quality, minutes) {
  const q = QUALITY[quality] || QUALITY.standard;
  const m = Math.max(0, Number(minutes) || 0);
  if (FORMATS[format]?.kind === 'video') return ((q.vbps + q.abps) * m * 60 / 8) / 1e6;
  if (format === 'wav') return (48000 * 2 * 2 * m * 60) / 1e6;
  return (q.abps * m * 60 / 8) / 1e6;
}
