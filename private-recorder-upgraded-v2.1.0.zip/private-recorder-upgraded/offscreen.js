import { FORMATS, QUALITY } from './shared.js';

let stream = null;
let outputStream = null;
let recorder = null;
let chunks = [];
let format = 'mp4';
let token = null;
let playCtx = null;
let renderVideo = null;
let renderCanvas = null;
let renderFrame = 0;
let stopping = false;
let lastUrl = null;

const VIDEO_TYPES = {
  mp4: ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4'],
  webm: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
};
const AUDIO_TYPES = ['audio/mp4;codecs=mp4a.40.2', 'audio/mp4', 'audio/mpeg', 'audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm'];
const pick = list => list.find(m => MediaRecorder.isTypeSupported(m)) || '';

function expectToken(t) {
  if (typeof t !== 'string' || t !== token) throw new Error('Invalid recorder token.');
}

function stopTracks() {
  for (const s of [stream, outputStream]) if (s) s.getTracks().forEach(t => t.stop());
  stream = outputStream = null;
}

function cleanupCanvas() {
  if (renderFrame) cancelAnimationFrame(renderFrame);
  renderFrame = 0;
  if (renderVideo) { renderVideo.pause(); renderVideo.srcObject = null; renderVideo.remove(); }
  renderVideo = null; renderCanvas = null;
}

async function start({ token: startToken, streamId, format: fmt }) {
  const quality = 'high';
  if (!Object.prototype.hasOwnProperty.call(FORMATS, fmt)) throw new Error('Unsupported recording format.');
  if (typeof streamId !== 'string' || streamId.length < 8 || streamId.length > 512 || /[\u0000-\u001f\u007f]/.test(streamId)) throw new Error('Invalid capture stream.');
  if (fmt === 'mp4' || fmt === 'webm') {
    if (!pick(VIDEO_TYPES[fmt])) throw new Error(`${fmt.toUpperCase()} is not available in this Chromium build.`);
  } else if (fmt === 'm4a') {
    if (!pick(['audio/mp4;codecs=mp4a.40.2', 'audio/mp4'])) throw new Error('M4A/AAC is not available in this Chromium build.');
  }
  const audioMime = pick(AUDIO_TYPES);
  if ((fmt === 'wav' || fmt === 'mp3') && !audioMime) throw new Error('Audio capture is not available in this Chromium build.');
  if (fmt === 'mp3' && !MediaRecorder.isTypeSupported('audio/mpeg')) throw new Error('MP3 recording is not supported by this Chromium build.');

  format = fmt; token = startToken; chunks = []; stopping = false;
  const q = QUALITY[quality];
  const source = { chromeMediaSource: 'tab', chromeMediaSourceId: streamId };
  stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: source },
    video: (fmt === 'mp4' || fmt === 'webm') ? { mandatory: { ...source, maxWidth: q.maxW, maxHeight: q.maxH, maxFrameRate: q.fps } } : false
  });

  if (!stream.getAudioTracks().length) throw new Error('The selected tab did not provide an audio track.');
  if (fmt === 'mp4' || fmt === 'webm') {
    const vt = stream.getVideoTracks()[0];
    if (!vt) throw new Error('The selected tab did not provide a video track.');
    const settings = vt.getSettings();
    if (!settings.width || !settings.height) throw new Error('The captured video size is unknown.');
  }

  playCtx = new AudioContext();
  playCtx.createMediaStreamSource(stream).connect(playCtx.destination);
  await playCtx.resume().catch(() => {});

  outputStream = stream;
  let mime = fmt === 'mp4' ? pick(VIDEO_TYPES.mp4) : fmt === 'webm' ? pick(VIDEO_TYPES.webm) : fmt === 'm4a' ? pick(['audio/mp4;codecs=mp4a.40.2', 'audio/mp4']) : fmt === 'mp3' ? 'audio/mpeg' : audioMime;

  const opts = { mimeType: mime, audioBitsPerSecond: q.abps };
  if (fmt === 'mp4' || fmt === 'webm') opts.videoBitsPerSecond = q.vbps;
  recorder = new MediaRecorder(outputStream, opts);
  recorder.ondataavailable = e => { if (e.data?.size) chunks.push(e.data); };
  recorder.onerror = e => finishError(e.error?.message || 'The browser recorder failed.');
  recorder.onstop = finalize;
  outputStream.getTracks().forEach(t => t.addEventListener('ended', stop, { once: true }));
  recorder.start(1000);
}

function stop() {
  if (stopping) return;
  stopping = true;
  try { if (recorder && recorder.state !== 'inactive') recorder.stop(); } catch {}
  cleanupCanvas();
  if (playCtx) { playCtx.close().catch(() => {}); playCtx = null; }
  stopTracks();
}

async function encodeWav(blob) {
  const ctx = new AudioContext();
  try {
    const audio = await ctx.decodeAudioData(await blob.arrayBuffer());
    const channels = Math.min(2, Math.max(1, audio.numberOfChannels));
    const frameCount = audio.length;
    const bytesPerSample = 2;
    const dataBytes = frameCount * channels * bytesPerSample;
    const buffer = new ArrayBuffer(44 + dataBytes);
    const view = new DataView(buffer);
    const write = (offset, str) => { for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i)); };
    write(0, 'RIFF'); view.setUint32(4, 36 + dataBytes, true); write(8, 'WAVE'); write(12, 'fmt ');
    view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, channels, true);
    view.setUint32(24, audio.sampleRate, true); view.setUint32(28, audio.sampleRate * channels * bytesPerSample, true);
    view.setUint16(32, channels * bytesPerSample, true); view.setUint16(34, 16, true); write(36, 'data'); view.setUint32(40, dataBytes, true);
    const left = audio.getChannelData(0), right = channels === 2 ? audio.getChannelData(1) : left;
    let off = 44;
    for (let i = 0; i < frameCount; i++) {
      for (let c = 0; c < channels; c++) {
        const v = Math.max(-1, Math.min(1, c === 0 ? left[i] : right[i]));
        view.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7fff, true); off += 2;
      }
      if (i % 262144 === 0) await new Promise(r => setTimeout(r, 0));
    }
    return new Blob([buffer], { type: 'audio/wav' });
  } finally { await ctx.close().catch(() => {}); }
}

async function finalize() {
  try {
    const raw = new Blob(chunks, { type: recorder?.mimeType || 'application/octet-stream' });
    chunks = [];
    if (!raw.size) throw new Error('Nothing was recorded. Make sure the media was playing.');
    const blob = format === 'wav' ? await encodeWav(raw) : raw;
    if (lastUrl) URL.revokeObjectURL(lastUrl);
    lastUrl = URL.createObjectURL(blob);
    const mime = format === 'mp4' ? 'video/mp4' : format === 'webm' ? 'video/webm' : format === 'm4a' ? 'audio/mp4' : format === 'mp3' ? 'audio/mpeg' : 'audio/wav';
    chrome.runtime.sendMessage({ target: 'background', type: 'offscreen-finished', token, url: lastUrl, ext: format, mime }).catch(() => {});
  } catch (e) { await finishError(e.message); }
}

async function finishError(message) {
  try { chrome.runtime.sendMessage({ target: 'background', type: 'offscreen-error', token, error: String(message || 'Recording failed.').slice(0, 240) }); } catch {}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen' || sender.id !== chrome.runtime.id) return;
  (async () => {
    try {
      if (msg.type === 'start') await start(msg);
      else if (msg.type === 'stop') { expectToken(msg.token); stop(); }
      else if (msg.type === 'pause') { expectToken(msg.token); if (recorder?.state === 'recording') recorder.pause(); }
      else if (msg.type === 'resume') { expectToken(msg.token); if (recorder?.state === 'paused') recorder.resume(); }
      else if (msg.type === 'release') { expectToken(msg.token); if (msg.url === lastUrl) { URL.revokeObjectURL(lastUrl); lastUrl = null; } }
      sendResponse({ ok: true });
    } catch (e) { sendResponse({ ok: false, error: String(e.message || e) }); }
  })();
  return true;
});
